﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            /// how to communicate between pages
            /// 1. QueryString
            /// 2. Cookies
            /// 3. Sessions
            /// 4. Databases

            // retrieve first name from textbox
            string FName = txtFirstName.Text;

            // retrieve last name from textbox
            string LName = txtLastName.Text;

            // create a cookie object
            HttpCookie myCookie = new HttpCookie("lastName_cook");
            // add the value to the cookie
            myCookie.Value = LName;
            // add the cookie to the cookies
            Response.Cookies.Add(myCookie);

            string hidden_key = txtPassword.Text;

            // added a session
            Session.Add("hidden_key", hidden_key);

           // Response.Write(hidden_key);

           // Response.Write("HI" + txtFirstName);

            Response.Redirect("SecondPage.aspx?FName=" + FName + "&blah=1");

            
        }
    }
}